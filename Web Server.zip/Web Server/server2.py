# Creating Enviroment:: $ py -3 -m venv venv
# Activating Enviroment :: venv\Scripts\activate
# Installing Flask :: pip3 install Flask
# Reference : https://flask.palletsprojects.com/en/1.1.x/quickstart/
# Reference : https://flask.palletsprojects.com/en/1.1.x/installation/#installation

from flask import Flask, render_template
app =Flask(__name__)


@app.route('/')
# Here any time we hit "http://127.0.0.1:5000/" or root we want to define a funtion  below:
def hello_world():
	return 'Hello. '

@app.route('/name')
# Here any time we hit "http://127.0.0.1:5000/name" or root we want to define a funtion  below:
def f_name():
	return 'Hello, Rehan '
