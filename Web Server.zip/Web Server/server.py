# Creating Enviroment:: $ py -3 -m venv venv
# Activating Enviroment :: venv\Scripts\activate
# Installing Flask :: pip3 install Flask
# Reference : https://flask.palletsprojects.com/en/1.1.x/quickstart/
# Reference : https://flask.palletsprojects.com/en/1.1.x/installation/#installation

# before running server be sure we must activate the enviroment.

from flask import Flask, render_template
app =Flask(__name__)

# print (__name__) # output => __manin__

# calling a html file using render_templates modules
@app.route('/about')
def about():
	return render_template('index.html')

# Here any time we hit "http://127.0.0.1:5000/" or root to call a funtion  below:
@app.route('/')
def hello():
	return 'Hello World. '

# Here any time we hit "http://127.0.0.1:5000/name" to call a funtion  below
@app.route('/name')
def f_name():
	return 'Hello, Rehan '

# Here any time we hit "http://127.0.0.1:5000/address" to call a funtion  below
@app.route('/address')
def address():
	return 'London'


# set  FLASK_ENV=development =>to update the server in real time without restating it
# set FLASK_APP=server.py   => it required to restart the server every time we make any changes
# flask run
# run "http://127.0.0.1:5000/"